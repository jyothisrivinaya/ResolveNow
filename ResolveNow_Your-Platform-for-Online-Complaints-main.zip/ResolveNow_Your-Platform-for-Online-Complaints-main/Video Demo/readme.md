Video demonstration of project
